
(()=>{'use strict';
const $=s=>document.getElementById(s),SVG='http://www.w3.org/2000/svg';
const {TXT, positive, negative, positiveText, negativeText, passages} = JSON.parse($('formula-data').textContent);
const labelSizes = new Map();

const cx=380,cy=380,radius=190;
let side=1,selected=0,phase='idle',shown=10,progress=1,run=0,context=null,soundOn=false,shards=[],animatingShards=false;
const words=()=>side===1?positive:negative,phrases=()=>side===1?positiveText:negativeText;
function e(tag,attrs,parent){const n=document.createElementNS(SVG,tag);Object.entries(attrs||{}).forEach(([k,v])=>n.setAttribute(k,v));parent.appendChild(n);return n}
const angle=i=>-Math.PI/2+side*i*2*Math.PI/10;
const point=i=>({x:cx+radius*Math.cos(angle(i)),y:cy+radius*Math.sin(angle(i))});
const loc=i=>({x:cx+(radius+((i===0||i===5)?76:80))*Math.cos(angle(i)),y:cy+(radius+((i===0||i===5)?76:80))*Math.sin(angle(i))});
function draw(){const paths=$('orbit-rings'),nodes=$('orbit-nodes');paths.replaceChildren();nodes.replaceChildren();
  const w=words(), sign=side===1?'+':'−';
  for(let i=0;i<10;i++){
   const q=i<shown?1:(i===shown?progress:0);if(q<=0)continue;
   let d='';const max=Math.max(2,Math.ceil(q*38));for(let j=0;j<=max;j++){const t=q*j/max,a=angle(i)+side*t*Math.PI/5;d+=(j?'L':'M')+(cx+radius*Math.cos(a)).toFixed(1)+','+(cy+radius*Math.sin(a)).toFixed(1)}
   e('path',{d,class:'orbit-line',opacity:phase==='shattered'?'0':'1'},paths);
   if(q===1){let t=.54,a=angle(i)+side*t*Math.PI/5,p={x:cx+radius*Math.cos(a),y:cy+radius*Math.sin(a)},tang=a+side*Math.PI/2;
      let dx=Math.cos(tang),dy=Math.sin(tang),nx=-dy,ny=dx;
      e('path',{d:`M${p.x+7*dx} ${p.y+7*dy} L${p.x-5*dx+4*nx} ${p.y-5*dy+4*ny} L${p.x-5*dx-4*nx} ${p.y-5*dy-4*ny} Z`,class:'orbit-tick'},paths);}
  }
  for(let i=0;i<10;i++){
    if(i!==0 && i>shown+(progress>=1?1:0))continue;
    const p=point(i),l=loc(i);
    if (i===2 || i===8) l.x += 22 * Math.sign(l.x-cx);
    const g=e('g',{class:'orbit-node'+(selected===i-1&&phase!=='birth'?' active':''),role:i?'button':'img',tabindex:i?'0':'-1','aria-label':i?sign+i+' '+w[i-1]:'0'},nodes);
    e('circle',{cx:p.x,cy:p.y,r:i?12:8,class:'orbit-dot'},g);
    if(i===0){const n=e('text',{x:l.x,y:l.y+14,class:'orb-number orb-zero','text-anchor':'middle'},g);n.textContent='0'}else{
      // Labels are at deliberate radial anchors: no drifting, no overlapping ring.
      const num=e('text',{x:l.x,y:l.y-15,class:'orb-number','text-anchor':'middle'},g);num.setAttribute('direction','ltr');num.textContent=sign+i;
      const tx=e('text',{x:l.x,y:l.y+38,class:'orb-label','text-anchor':'middle'},g);tx.setAttribute('direction','ltr');tx.textContent=w[i-1];
      // Size from the rendered glyphs and the horizontal space at this anchor.
      const label = w[i-1];
      const key = i + ':' + side + ':' + label;
      if (!labelSizes.has(key)) {
        const width = tx.getComputedTextLength();
        const available = Math.min(148, 2 * Math.min(l.x - 12, 748 - l.x));
        const fontSize = parseFloat(getComputedStyle(tx).fontSize);
        if (width > 0) labelSizes.set(key, width > available ? (fontSize * available / width) + 'px' : '');
      }
      tx.style.fontSize = labelSizes.get(key) || '';
    }
    if(i){e('circle',{cx:p.x,cy:p.y,r:40,class:'orbit-hit'},g);
      g.addEventListener('click',()=>focus(i-1));g.addEventListener('keydown',ev=>{if(ev.key==='Enter'||ev.key===' '){ev.preventDefault();focus(i-1)}});}
  }
  const c=$('center-title'),s=$('center-sub');c.replaceChildren();
  let title,sub='';
  if(phase==='birth'){
    if(shown===0&&progress===0){title='0';sub=TXT.zeroSub;}
    else if(shown===0){title=w[0];sub=side===1?TXT.firstPosSub:TXT.firstNegSub;}
    else if(shown<9){title=w[shown-1];sub=phrases()[shown-1];}
    else{title=w[8];sub=phrases()[8];}
  }else if(phase==='shattered'){title=TXT.brokenTitle;sub=TXT.brokenSub;}
  else if(phase==='focused'){title=w[selected];sub=TXT.focusSub;}
  else{title=TXT.wholeTitle;sub=TXT.wholeSub;}
  const len=title.length;c.style.fontSize=len>15?'22px':len>11?'24px':'30px';c.textContent=title;s.textContent=sub;
  const titleWidth=c.getComputedTextLength();
  if(titleWidth>315)c.style.fontSize=(parseFloat(c.style.fontSize)*315/titleWidth)+'px';
  s.style.fontSize='';
  const width=s.getComputedTextLength();
  s.style.fontSize=width>320?(18*320/width)+'px':'';
}
function readingLink(index) {
  const link = $('read-transition');
  const part = side === 1 ? 'plus' : 'minus';
  link.hash = part + '-' + (index + 1);
}
function panel(text,desc,kicker=TXT.linkKicker){const label=$('eyebrow');label.textContent=kicker;$('panel-title').textContent=text;$('panel-text').textContent=desc;}
function scrollFocus(){requestAnimationFrame(()=>{$('art').scrollIntoView({behavior:'smooth',block:'center'});});}
function cancel(){run++;phase='idle'}
function ping(n){if(!soundOn)return;try{context=context||new(window.AudioContext||window.webkitAudioContext)();context.resume();let t=context.currentTime,osc=context.createOscillator(),gain=context.createGain();osc.type='sine';osc.frequency.value=540+n*33;gain.gain.setValueAtTime(.0001,t);gain.gain.exponentialRampToValueAtTime(.065,t+.025);gain.gain.exponentialRampToValueAtTime(.0001,t+.42);osc.connect(gain).connect(context.destination);osc.start(t);osc.stop(t+.43)}catch(err){}}
const sleep=ms=>new Promise(res=>setTimeout(res,ms));
function animate(duration,fn,id){return new Promise(resolve=>{const t0=performance.now();function f(t){if(run!==id){resolve(false);return}let x=Math.min(1,(t-t0)/duration);fn(x);if(x<1)requestAnimationFrame(f);else resolve(true)}requestAnimationFrame(f)})}
async function birth(){cancel();const id=run;phase='birth';shown=0;progress=0;selected=0;$('relations').hidden=true;$('back').hidden=true;$('repair').hidden=true;clearShards();draw();panel(TXT.beginTitle,TXT.beginDesc,TXT.birthKicker);ping(0);await sleep(600);if(run!==id)return;
  const w=words();for(let i=0;i<9;i++){
   if(run!==id)return;shown=i;progress=0;readingLink(i);panel(i===0?(TXT.birthFirst.includes('{a}')?TXT.birthFirst.replace('{a}',w[0]):w[0]):phrases()[i-1],i===0?(side===1?TXT.birthFirstDesc:TXT.firstNegSub):phrases()[(i-1)%9],`${side===1?'+':'−'}${i+1} / 9`);
   if(!await animate(1550,x=>{progress=1-Math.pow(1-x,2.1);draw()},id))return;
   shown=i+1;progress=0;draw();ping(i+1);await sleep(575);
  }
  if(run!==id)return;shown=9;progress=0;panel(phrases()[8],TXT.returnDesc,TXT.linkKicker);
  if(!await animate(1600,x=>{progress=1-Math.pow(1-x,2.1);draw()},id))return;
  phase='idle';shown=10;progress=1;draw();panel(TXT.closedTitle,TXT.closedDesc,TXT.closedKicker);$('status').textContent=TXT.statusTouch;
}
function complete(){readingLink(0);cancel();clearShards();shown=10;progress=1;phase='idle';$('relations').hidden=true;$('back').hidden=true;draw();panel(TXT.closedTitle,TXT.closedDesc,TXT.closedKicker)}
function choices(){const f=$('focus'),m=$('missing');let old=f.value||'2';f.replaceChildren();words().forEach((w,i)=>{let o=document.createElement('option');o.value=i;o.textContent=w;f.append(o)});f.value=old;m.replaceChildren();words().forEach((w,i)=>{if(i===Number(f.value))return;let o=document.createElement('option');o.value=i;o.textContent=w;m.append(o)})}
function switchSide(n){if(n===side)return;side=n;readingLink(0);$('orbit').setAttribute('aria-label',side===1?TXT.positive:TXT.negative);document.body.classList.toggle('reverse',side===-1);$('positive').classList.toggle('active',side===1);$('negative').classList.toggle('active',side===-1);$('positive').setAttribute('aria-pressed',side===1?'true':'false');$('negative').setAttribute('aria-pressed',side===-1?'true':'false');choices();scrollFocus();birth()}
function focus(i){readingLink(i);if(phase==='shattered')clearShards();cancel();selected=i;shown=10;progress=1;phase='focused';draw();const w=words(),other=[];for(let j=1;j<9;j++)other.push((i+j)%9);$('quality-grid').replaceChildren();other.forEach(k=>{const b=document.createElement('button');b.className='quality';b.innerHTML=`<bdi dir="ltr">${side===1?'+':'−'}${k+1}</bdi>`;b.append(document.createTextNode(w[k]));b.addEventListener('click',()=>focus(k));$('quality-grid').append(b)});$('relation-title').textContent=TXT.relationTitle.includes('{a}')?TXT.relationTitle.replace('{a}',w[i]):TXT.relationTitle+' · '+w[i];$('relations').hidden=false;$('back').hidden=false;panel(w[i],passages[(side===1?0:9)+i],TXT.focusKicker);$('status').textContent=TXT.statusWhole;}
function clearShards(){const c=$('particles');const ctx=c.getContext('2d');ctx.clearRect(0,0,c.width,c.height);$('orbit-rings').style.opacity='1';$('orbit-nodes').style.opacity='1';animatingShards=false;}
async function shatter(){scrollFocus();await sleep(550);const focusN=Number($('focus').value),missingN=Number($('missing').value);cancel();selected=focusN;shown=10;progress=1;phase='shattered';draw();panel(TXT.shatterTitle.includes('{a}')?TXT.shatterTitle.replace('{a}',words()[missingN]):TXT.shatterTitle+' · '+words()[missingN],TXT.shatterDesc,TXT.shatterKicker);$('relations').hidden=true;$('back').hidden=true;$('repair').hidden=false;
  const canvas=$('particles'),svg=$('orbit'),r=svg.getBoundingClientRect(),pr=Math.min(devicePixelRatio||1,2);canvas.width=Math.round(r.width*pr);canvas.height=Math.round(r.height*pr);const ctx=canvas.getContext('2d');ctx.setTransform(pr,0,0,pr,0,0);
  const scale=r.width/760;shards=[];for(let j=0;j<320;j++){let a=Math.random()*Math.PI*2,rr=radius+(Math.random()-.5)*11;shards.push({x:(cx+rr*Math.cos(a))*scale,y:(cy+rr*Math.sin(a))*scale,vx:(Math.cos(a)*140+(Math.random()-.5)*80)*scale,vy:(Math.sin(a)*140+(Math.random()-.5)*80)*scale,size:(1+Math.random()*3)*scale,spin:Math.random()*5})}
  $('orbit-rings').style.opacity=0;$('orbit-nodes').style.opacity=0;animatingShards=true;let t0=performance.now();function frame(t){if(!animatingShards)return;const v=Math.min(1,(t-t0)/1550);ctx.clearRect(0,0,r.width,r.height);const color=side===1?'#efcf91':'#efada6';for(let p of shards){ctx.save();ctx.globalAlpha=(1-v)*.9;ctx.fillStyle=color;ctx.shadowColor=color;ctx.shadowBlur=7;ctx.translate(p.x+p.vx*v,p.y+p.vy*v);ctx.rotate(p.spin*v);ctx.fillRect(-p.size/2,-p.size/2,p.size,p.size/2);ctx.restore()}if(v<1)requestAnimationFrame(frame);else animatingShards=false}requestAnimationFrame(frame);
  $('status').textContent=TXT.statusBroken;
}
function enter(){if($('intro').classList.contains('off'))return;try{context=context||new(window.AudioContext||window.webkitAudioContext)();context.resume();soundOn=true;$('sound').textContent=TXT.soundOn}catch(err){}$('intro').classList.add('off');setTimeout(()=>{$('intro').style.display='none'},900);scrollFocus();birth()}
function skip(){ $('intro').classList.add('off');setTimeout(()=>{$('intro').style.display='none'},900);complete();scrollFocus()}
$('intro-hit').addEventListener('click',enter);$('intro-hit').addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();enter()}});$('skip').addEventListener('click',e=>{e.stopPropagation();skip()});$('positive').addEventListener('click',()=>switchSide(1));$('negative').addEventListener('click',()=>switchSide(-1));$('next').addEventListener('click',()=>focus((selected+1)%9));$('back').addEventListener('click',complete);$('break').addEventListener('click',shatter);$('repair').addEventListener('click',complete);$('focus').addEventListener('change',choices);$('replay').addEventListener('click',()=>{scrollFocus();birth()});$('sound').addEventListener('click',()=>{soundOn=!soundOn;$('sound').textContent=soundOn?TXT.soundOn:TXT.soundOff;if(soundOn)ping(1)});document.querySelectorAll('[data-focus]').forEach(b=>b.addEventListener('click',()=>{if(side===-1)switchSide(1);scrollFocus();focus(Number(b.dataset.focus))}));
$('language-switch').addEventListener('change',function(){rememberLanguage(this.value);
  window.location.href = new URL('../' + encodeURIComponent(this.value) + '/', window.location.href).href;});
choices();draw();
document.fonts.ready.then(()=>{labelSizes.clear();draw()});
$('intro').hidden = false;
if (location.hash && document.getElementById(location.hash.slice(1))) {
  $('intro').hidden = true;
  complete();
}
if(window.matchMedia('(prefers-reduced-motion:reduce)').matches){$('intro-hit').removeEventListener('click',enter);$('intro-hit').addEventListener('click',skip);}
})();
