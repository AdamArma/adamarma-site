(() => {
  'use strict';
  const id = 114436589;
  const key = 'adamarma.analytics.yandex.v1';
  const settings = document.querySelector('[data-metrika-settings]');
  if (!settings) return;
  const allow = settings.querySelector('[data-metrika-allow]');
  const decline = settings.querySelector('[data-metrika-decline]');
  const status = settings.querySelector('output');
  let started = false;

  function readChoice() {
    try {
      return Number(localStorage.getItem(key)) > Date.now();
    } catch {
      return false;
    }
  }

  function displayChoice(value) {
    status.textContent = value ? status.dataset.allowed : status.dataset.denied;
    allow.setAttribute('aria-pressed', String(value));
    decline.setAttribute('aria-pressed', String(!value));
  }

  function start() {
    if (started) return;
    started = true;
    displayChoice(true);
    window.ym = window.ym || function () {
      (window.ym.a ||= []).push(arguments);
    };
    window.ym.l = Date.now();
    window.ym(id, 'init', {
      ssr: true,
      webvisor: true,
      clickmap: true,
      ecommerce: false,
      referrer: document.referrer,
      url: location.href,
      accurateTrackBounce: true,
      trackLinks: true
    });
    const script = document.createElement('script');
    script.async = true;
    script.src = 'https://mc.yandex.ru/metrika/tag.js?id=' + id;
    document.head.append(script);
  }

  function stop() {
    displayChoice(false);
    if (!started) return;
    window.ym(id, 'destruct');
    location.reload();
  }

  allow.disabled = false;
  decline.disabled = false;
  allow.addEventListener('click', () => {
    try { localStorage.setItem(key, Date.now() + 180 * 86400000); } catch {}
    start();
  });
  decline.addEventListener('click', () => {
    try { localStorage.removeItem(key); } catch {}
    stop();
  });
  window.addEventListener('storage', event => {
    if ((event.key === key || event.key === null) && !readChoice()) stop();
  });
  window.addEventListener('pageshow', event => {
    if (event.persisted && !readChoice()) stop();
  });
  if (readChoice()) start();
  else displayChoice(false);
})();
