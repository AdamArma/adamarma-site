(() => {
  'use strict';
  const id = 114436589;
  const key = 'adamarma.analytics.yandex.v1';
  const settings = document.querySelector('[data-metrika-settings]');
  if (!settings) return;
  const allow = settings.querySelector('[data-metrika-allow]');
  const decline = settings.querySelector('[data-metrika-decline]');
  const status = settings.querySelector('output');
  const banner = document.querySelector('[data-metrika-banner]');
  const bannerAllow = banner.querySelector('[data-metrika-banner-allow]');
  const bannerDecline = banner.querySelector('[data-metrika-banner-decline]');
  let started = false;
  let pageChoice = null;
  let readingSettings = false;

  function readChoice() {
    try {
      const expiry = Number(localStorage.getItem(key));
      return Math.abs(expiry) > Date.now() ? expiry > 0 : null;
    } catch {
      return null;
    }
  }

  function displayChoice(value) {
    status.textContent = value ? status.dataset.allowed : status.dataset.denied;
    allow.setAttribute('aria-pressed', String(value));
    decline.setAttribute('aria-pressed', String(!value));
  }

  function start() {
    if (started) return;
    started = true;
    displayChoice(true);
    window.ym = window.ym || function () {
      (window.ym.a ||= []).push(arguments);
    };
    window.ym.l = Date.now();
    window.ym(id, 'init', {
      ssr: true,
      webvisor: true,
      clickmap: true,
      ecommerce: false,
      referrer: document.referrer,
      url: location.href,
      accurateTrackBounce: true,
      trackLinks: true
    });
    const script = document.createElement('script');
    script.async = true;
    script.src = 'https://mc.yandex.ru/metrika/tag.js?id=' + id;
    document.head.append(script);
  }

  function stop() {
    displayChoice(false);
    if (!started) return;
    window.ym(id, 'destruct');
    location.reload();
  }

  function refresh() {
    const choice = pageChoice ?? readChoice();
    banner.hidden = choice !== null || readingSettings;
    if (choice === true) start();
    else stop();
  }

  function choose(value) {
    pageChoice = null;
    const expiry = Date.now() + 180 * 86400000;
    try {
      localStorage.setItem(key, value ? expiry : -expiry);
    } catch {
      pageChoice = value;
    }
    refresh();
  }

  allow.disabled = false;
  decline.disabled = false;
  for (const button of [allow, bannerAllow]) button.addEventListener('click', () => choose(true));
  for (const button of [decline, bannerDecline]) button.addEventListener('click', () => choose(false));
  banner.querySelector('a').addEventListener('click', () => {
    readingSettings = true;
    banner.hidden = true;
  });
  window.addEventListener('storage', event => {
    if (event.key === key || event.key === null) {
      pageChoice = null;
      refresh();
    }
  });
  window.addEventListener('pageshow', event => {
    if (event.persisted) refresh();
  });
  readingSettings = location.hash === '#arma-analytics-options';
  refresh();
})();
