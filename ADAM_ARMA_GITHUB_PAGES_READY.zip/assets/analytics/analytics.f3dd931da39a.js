(() => {
  'use strict';

  const id = 'G-ZN0G1XNL98';
  const disabled = 'ga-disable-' + id;
  const consentKey = 'adamarma.analytics.google.v1';
  const consentMaxAge = 180 * 24 * 60 * 60 * 1000;
  const settings = document.getElementById('arma-analytics-options');
  const allow = settings.querySelector('[data-analytics-allow]');
  const decline = settings.querySelector('[data-analytics-decline]');
  const status = settings.querySelector('output');
  const locale = document.documentElement.lang.toLowerCase();
  const pageLanguage = /^[a-z]{2}$/.test(locale) ? locale : 'und';
  const source = new URL(window.location.href);
  const pagePath = source.pathname.replace(/\/index\.html$/, '/');
  const isDebug = source.searchParams.get('aa_debug') === '1';
  const orbit = document.getElementById('art');
  const intro = document.getElementById('intro');
  const negative = document.getElementById('negative');
  const denied = {
    ad_storage: 'denied',
    ad_user_data: 'denied',
    ad_personalization: 'denied',
    analytics_storage: 'denied'
  };

  let enabled = false;
  let tagStarted = false;
  let orbitVisible = false;
  let side = currentSide();
  const seenSides = new Set();
  window[disabled] = true;

  function currentSide() {
    return negative?.getAttribute('aria-pressed') === 'true' ? 'negative' : 'positive';
  }

  function readChoice() {
    try {
      const value = JSON.parse(localStorage.getItem(consentKey));
      return value?.allow === true && Date.now() < value.until;
    } catch {
      return false;
    }
  }

  function saveChoice(value) {
    try {
      localStorage.setItem(consentKey, JSON.stringify({allow: value, until: Date.now() + consentMaxAge}));
    } catch {
      // A blocked storage implementation leaves the choice valid for this page only.
    }
  }

  function updateControls() {
    status.textContent = enabled ? status.dataset.allowed : status.dataset.denied;
    allow.setAttribute('aria-pressed', String(enabled));
    decline.setAttribute('aria-pressed', String(!enabled));
  }

  function clearGoogleCookies() {
    const names = document.cookie.split(';').map(entry => entry.trim().split('=')[0]);
    for (const name of names.filter(name => /^_ga(?:_[A-Z0-9]+)?$/.test(name))) {
      for (const domain of ['', '; Domain=' + location.hostname, '; Domain=adamarma.ru']) {
        document.cookie = name + '=; Max-Age=0; Path=/; SameSite=Lax' + domain;
      }
    }
  }

  function referrerOrigin() {
    try {
      const referrer = new URL(document.referrer);
      return /^https?:$/.test(referrer.protocol) ? referrer.origin + '/' : '';
    } catch {
      return '';
    }
  }

  function campaignParameters() {
    const keys = {
      utm_source: 'campaign_source',
      utm_medium: 'campaign_medium',
      utm_campaign: 'campaign_name',
      utm_id: 'campaign_id',
      utm_content: 'campaign_content',
      utm_term: 'campaign_term'
    };
    const values = {};
    for (const [query, field] of Object.entries(keys)) {
      const value = source.searchParams.get(query);
      if (value && /^[\p{L}\p{N}][\p{L}\p{N} _-]{0,63}$/u.test(value) && !/\d{7,}/.test(value)) {
        values[field] = value;
      }
    }
    return values;
  }

  function send(name, parameters = {}) {
    if (!enabled || !tagStarted) return;
    window.gtag('event', name, {send_to: id, ...parameters});
  }

  function start() {
    enabled = true;
    window[disabled] = false;
    updateControls();
    if (tagStarted) return;
    tagStarted = true;

    window.dataLayer = window.dataLayer || [];
    window.gtag = function () { window.dataLayer.push(arguments); };
    window.gtag('consent', 'default', denied);
    window.gtag('consent', 'update', {...denied, analytics_storage: 'granted'});
    window.gtag('js', new Date());
    window.gtag('set', {
      page_location: source.origin + pagePath,
      page_referrer: referrerOrigin(),
      page_language: pageLanguage,
      allow_google_signals: false,
      allow_ad_personalization_signals: false,
      ...(isDebug ? {debug_mode: true} : {})
    });
    window.gtag('config', id, {
      send_page_view: false,
      ...campaignParameters()
    });

    const script = document.createElement('script');
    script.async = true;
    script.src = 'https://www.googletagmanager.com/gtag/js?id=' + id;
    document.head.append(script);

    send('page_view');
    const step = pagePath.endsWith('/guide/') && transition(source.hash);
    if (step) send('formula_explanation', {...step, explanation_surface: 'guide'});
    recordVisibleSide();
  }

  function stop() {
    enabled = false;
    window[disabled] = true;
    clearGoogleCookies();
    updateControls();
    if (tagStarted) location.reload();
  }

  function transition(value) {
    const match = /^(?:#)?(plus|minus)-([1-9])$/.exec(value);
    if (!match) return null;
    const formulaSide = match[1] === 'plus' ? 'positive' : 'negative';
    return {formula_side: formulaSide, concept_id: formulaSide + '_' + match[2]};
  }

  function concept(value, formulaSide = currentSide()) {
    const match = /^[+−-]([1-9])(?:\s|$)/.exec(value ?? '');
    return match ? {formula_side: formulaSide, concept_id: formulaSide + '_' + match[1]} : null;
  }

  function recordVisibleSide() {
    if (!enabled || !orbitVisible || (intro && !intro.hidden && !intro.classList.contains('off'))) return;
    if (seenSides.has(side)) return;
    seenSides.add(side);
    send('formula_view', {formula_side: side});
  }

  function selectConcept(target) {
    const node = target.closest('#orbit-nodes .orbit-node[role="button"]');
    if (node) return concept(node.getAttribute('aria-label'));
    const quality = target.closest('#quality-grid .quality');
    if (quality) return concept(quality.querySelector('span')?.textContent);
    const shortcut = target.closest('[data-focus]');
    const number = shortcut ? Number(shortcut.dataset.focus) + 1 : 0;
    if (Number.isInteger(number) && number >= 1 && number <= 9) return concept('+' + number, 'positive');
    if (!target.closest('#next')) return null;
    const current = document.querySelector('#orbit-nodes .orbit-node.active[role="button"]');
    const active = /^[+−-]([1-9])\s/.exec(current?.getAttribute('aria-label') ?? '');
    return active ? concept('+' + (Number(active[1]) % 9 + 1)) : null;
  }

  function recordSelection(target) {
    const item = selectConcept(target);
    if (!item) return;
    send('formula_select', item);
    send('formula_explanation', {...item, explanation_surface: 'inline'});
  }

  function recordLink(link) {
    const target = new URL(link.href, location.href);
    const toLanguage = target.origin === location.origin && /^[a-z]{2}$/.test(link.dataset.lang ?? '')
      ? link.dataset.lang : '';
    if (toLanguage && toLanguage !== pageLanguage) {
      send('language_switch', {target_language: toLanguage});
    }
    if (target.origin === location.origin && /^\/[a-z]{2}\/guide\/$/.test(target.pathname)
        && !pagePath.endsWith('/guide/')) {
      send('formula_guide_open', transition(target.hash) ?? {});
    }
    if (target.origin === location.origin && target.pathname === pagePath && pagePath.endsWith('/guide/')) {
      const step = transition(target.hash);
      if (step) send('formula_explanation', {...step, explanation_surface: 'guide'});
    }
    const product = link.dataset.analyticsProduct;
    if (/^[a-z0-9_-]{1,40}$/.test(product ?? '')) send('product_open', {product_id: product});
  }

  allow.disabled = false;
  decline.disabled = false;
  allow.addEventListener('click', () => { saveChoice(true); start(); });
  decline.addEventListener('click', () => { saveChoice(false); stop(); });
  window.addEventListener('storage', event => {
    if ((event.key === consentKey || event.key === null) && !readChoice() && enabled) stop();
  });
  window.addEventListener('pageshow', event => {
    if (event.persisted && enabled && !readChoice()) stop();
  });
  document.addEventListener('click', event => {
    if (!enabled || !event.isTrusted || !(event.target instanceof Element)) return;
    recordSelection(event.target);
    const link = event.target.closest('a[href]');
    if (link) recordLink(link);
  }, true);
  document.addEventListener('keydown', event => {
    if (!enabled || !event.isTrusted || !(event.target instanceof Element)
        || !event.target.closest('#orbit-nodes .orbit-node[role="button"]')) return;
    if (!event.repeat && (event.key === 'Enter' || event.key === ' ')) recordSelection(event.target);
  }, true);
  document.addEventListener('change', event => {
    if (enabled && event.isTrusted && event.target.id === 'language-switch'
        && /^[a-z]{2}$/.test(event.target.value) && event.target.value !== pageLanguage) {
      send('language_switch', {target_language: event.target.value});
    }
  }, true);

  if (orbit && intro && negative) {
    const changes = new MutationObserver(() => {
      const nextSide = currentSide();
      if (nextSide !== side) {
        side = nextSide;
        send('formula_switch', {formula_side: side});
      }
      recordVisibleSide();
    });
    changes.observe(negative, {attributeFilter: ['aria-pressed']});
    changes.observe(intro, {attributeFilter: ['class', 'hidden']});
    if ('IntersectionObserver' in window) {
      new IntersectionObserver(([entry]) => {
        orbitVisible = entry.intersectionRatio >= 0.2;
        recordVisibleSide();
      }, {threshold: 0.2}).observe(orbit);
    }
  }

  updateControls();
  if (readChoice()) start();
})();
