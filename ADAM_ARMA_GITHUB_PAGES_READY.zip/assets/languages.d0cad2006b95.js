function rememberLanguage(code) {
  if (!/^[a-z]{2}$/.test(code)) return;
  try {
    localStorage.setItem('adamarma_lang', code);
    const secure = location.protocol === 'https:' ? '; Secure' : '';
    document.cookie = 'adamarma_lang=' + code + '; Path=/; Max-Age=31536000; SameSite=Lax' + secure;
  } catch (_) {
    // Navigation still works when a browser blocks storage.
  }
}

document.addEventListener('click', function (event) {
  const link = event.target.closest && event.target.closest('a[data-lang]');
  if (link && !event.ctrlKey && !event.metaKey && !event.shiftKey && !event.altKey) {
    rememberLanguage(link.dataset.lang);
  }
});

// Carry an existing v7 preference forward for later visits to the root address.
try {
  const existing = localStorage.getItem('adamarma_lang');
  if (existing && !document.cookie.split('; ').some(row => row.startsWith('adamarma_lang='))) {
    rememberLanguage(existing);
  }
} catch (_) {}
