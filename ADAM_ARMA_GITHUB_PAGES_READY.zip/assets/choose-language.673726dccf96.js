(() => {
  'use strict';
  if (new URLSearchParams(location.search).has('languages') || location.hash === '#languages') return;
  const supported = ["ru", "en", "ar", "zh", "es", "fr", "de", "it", "pt", "tr", "pl", "nl", "sv", "cs", "el", "uk", "kk", "uz", "he", "fa", "hi", "id", "vi", "th", "ja", "ko"];
  let saved;
  try { saved = localStorage.getItem('adamarma_lang'); } catch (_) {}
  const browser = (navigator.languages || [navigator.language || 'en']).map(s => s.toLowerCase().split('-')[0]);
  const language = supported.includes(saved) ? saved : browser.find(s => supported.includes(s)) || 'en';
  location.replace(new URL('./' + language + '/' + location.search + location.hash, location.href).href);
})();
