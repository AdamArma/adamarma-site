/* User-initiated sharing with no third-party scripts. */
(() => {
  'use strict';

  const translations = {
    ru: ['Поделиться', 'Скопировать ссылку', 'Ссылка скопирована', 'Электронная почта', 'Счастье начинается с правды. С той, которую ты говоришь самому себе.\n\nОткрой для себя Формулу счастья ADAM ARMA.'],
    en: ['Share', 'Copy link', 'Link copied', 'Email', 'Happiness begins with the truth. The truth you tell yourself.\n\nDiscover ADAM ARMA’s Formula of Happiness.'],
    ar: ['مشاركة', 'نسخ الرابط', 'تم نسخ الرابط', 'البريد الإلكتروني', 'تبدأ السعادة بالحقيقة. بالحقيقة التي تقولها لنفسك.\n\nاكتشف صيغة السعادة من ADAM ARMA.'],
    bn: ['শেয়ার করুন', 'লিংক কপি করুন', 'লিংক কপি হয়েছে', 'ইমেইল', 'সুখের শুরু সত্য দিয়ে। যে সত্য তুমি নিজেকে বলো।\n\nADAM ARMA-র সুখের সূত্র আবিষ্কার করো।'],
    cs: ['Sdílet', 'Zkopírovat odkaz', 'Odkaz zkopírován', 'E-mail', 'Štěstí začíná pravdou. Tou, kterou říkáš sám sobě.\n\nObjev vzorec štěstí od ADAM ARMA.'],
    de: ['Teilen', 'Link kopieren', 'Link kopiert', 'E-Mail', 'Glück beginnt mit der Wahrheit. Mit der Wahrheit, die du dir selbst sagst.\n\nEntdecke die Glücksformel von ADAM ARMA.'],
    el: ['Κοινοποίηση', 'Αντιγραφή συνδέσμου', 'Ο σύνδεσμος αντιγράφηκε', 'Email', 'Η ευτυχία αρχίζει με την αλήθεια. Με την αλήθεια που λες στον εαυτό σου.\n\nΑνακάλυψε τη φόρμουλα της ευτυχίας του ADAM ARMA.'],
    es: ['Compartir', 'Copiar enlace', 'Enlace copiado', 'Correo electrónico', 'La felicidad empieza con la verdad. Con la que te dices a ti mismo.\n\nDescubre la Fórmula de la Felicidad de ADAM ARMA.'],
    fa: ['اشتراک‌گذاری', 'کپی پیوند', 'پیوند کپی شد', 'ایمیل', 'خوشبختی با حقیقت آغاز می‌شود؛ با همان حقیقتی که به خودت می‌گویی.\n\nفرمول خوشبختی ADAM ARMA را کشف کن.'],
    fr: ['Partager', 'Copier le lien', 'Lien copié', 'E-mail', 'Le bonheur commence par la vérité. Celle que tu te dis à toi-même.\n\nDécouvre la formule du bonheur d’ADAM ARMA.'],
    he: ['שיתוף', 'העתקת קישור', 'הקישור הועתק', 'דוא״ל', 'האושר מתחיל באמת. באמת שאנחנו אומרים לעצמנו.\n\nבואו להכיר את נוסחת האושר של ADAM ARMA.'],
    hi: ['साझा करें', 'लिंक कॉपी करें', 'लिंक कॉपी हो गया', 'ईमेल', 'ख़ुशी की शुरुआत सच से होती है। उस सच से, जो आप ख़ुद से कहते हैं।\n\nADAM ARMA के ख़ुशी के सूत्र को जानिए।'],
    id: ['Bagikan', 'Salin tautan', 'Tautan disalin', 'Email', 'Kebahagiaan berawal dari kebenaran. Kebenaran yang kamu katakan kepada dirimu sendiri.\n\nTemukan Rumus Kebahagiaan ADAM ARMA.'],
    it: ['Condividi', 'Copia il link', 'Link copiato', 'E-mail', 'La felicità comincia dalla verità. Da quella che dici a te stesso.\n\nScopri la Formula della Felicità di ADAM ARMA.'],
    ja: ['共有', 'リンクをコピー', 'リンクをコピーしました', 'メール', '幸せは、本当のことを言うところから始まる。自分自身に、本当のことを。\n\nADAM ARMAの「幸せの公式」に触れてみよう。'],
    kk: ['Бөлісу', 'Сілтемені көшіру', 'Сілтеме көшірілді', 'Электрондық пошта', 'Бақыт шындықтан басталады. Өзіңе айтатын шындықтан.\n\nADAM ARMA-ның Бақыт формуласымен таныс.'],
    ko: ['공유', '링크 복사', '링크가 복사되었습니다', '이메일', '행복은 진실에서 시작됩니다. 스스로에게 말하는 그 진실에서요.\n\nADAM ARMA의 행복 공식을 만나 보세요.'],
    nl: ['Delen', 'Link kopiëren', 'Link gekopieerd', 'E-mail', 'Geluk begint met de waarheid. De waarheid die je jezelf vertelt.\n\nOntdek de geluksformule van ADAM ARMA.'],
    pl: ['Udostępnij', 'Skopiuj link', 'Link skopiowany', 'E-mail', 'Szczęście zaczyna się od prawdy. Od tej, którą mówisz sobie.\n\nOdkryj formułę szczęścia ADAM ARMA.'],
    pt: ['Compartilhar', 'Copiar link', 'Link copiado', 'E-mail', 'A felicidade começa com a verdade. Com a verdade que você diz a si mesmo.\n\nDescubra a Fórmula da Felicidade de ADAM ARMA.'],
    sv: ['Dela', 'Kopiera länk', 'Länken har kopierats', 'E-post', 'Lycka börjar med sanningen. Den sanning du säger till dig själv.\n\nUpptäck ADAM ARMAs lyckoformel.'],
    sw: ['Shiriki', 'Nakili kiungo', 'Kiungo kimenakiliwa', 'Barua pepe', 'Furaha huanza na ukweli. Ukweli unaojiambia mwenyewe.\n\nGundua Mfumo wa Furaha wa ADAM ARMA.'],
    th: ['แชร์', 'คัดลอกลิงก์', 'คัดลอกลิงก์แล้ว', 'อีเมล', 'ความสุขเริ่มต้นจากความจริง ความจริงที่คุณบอกกับตัวเอง\n\nมาค้นพบสูตรแห่งความสุขของ ADAM ARMA'],
    tr: ['Paylaş', 'Bağlantıyı kopyala', 'Bağlantı kopyalandı', 'E-posta', 'Mutluluk gerçekle başlar. Kendine söylediğin gerçekle.\n\nADAM ARMA’nın Mutluluk Formülü’nü keşfet.'],
    uk: ['Поділитися', 'Скопіювати посилання', 'Посилання скопійовано', 'Електронна пошта', 'Щастя починається з правди. З тієї, яку ти кажеш собі.\n\nВідкрий для себе Формулу щастя ADAM ARMA.'],
    uz: ['Ulashish', 'Havolani nusxalash', 'Havola nusxalandi', 'Elektron pochta', 'Baxt haqiqatdan boshlanadi. O‘zingga aytadigan haqiqatdan.\n\nADAM ARMAning Baxt formulasi bilan tanish.'],
    vi: ['Chia sẻ', 'Sao chép liên kết', 'Đã sao chép liên kết', 'Email', 'Hạnh phúc bắt đầu từ sự thật. Từ sự thật bạn nói với chính mình.\n\nKhám phá Công thức Hạnh phúc của ADAM ARMA.'],
    zh: ['分享', '复制链接', '链接已复制', '电子邮件', '幸福始于真话。始于你对自己说的真话。\n\n探索 ADAM ARMA 的幸福公式。']
  };

  const art = document.querySelector('#explore > #art');
  const guide = document.querySelector('header.read-nav');
  if ((!art && !guide) || document.querySelector('.arma-share')) return;

  const locale = document.documentElement.lang.toLowerCase().split('-')[0];
  const [label, copyLabel, copiedLabel, emailLabel, text] = translations[locale];
  const heading = document.querySelector('h1').textContent.trim();
  const title = 'ADAM ARMA — ' + heading;
  const url = document.querySelector('link[rel="canonical"]').href;
  const shareData = {title, text, url};
  const encode = encodeURIComponent;
  const destinations = [
    ['telegram', 'Telegram', 'https://t.me/share/url?url=' + encode(url) + '&text=' + encode(text)],
    ['whatsapp', 'WhatsApp', 'https://api.whatsapp.com/send?text=' + encode(text + '\n\n' + url)],
    ['vk', 'VK', 'https://vk.com/share.php?url=' + encode(url) + '&title=' + encode(title)],
    ['facebook', 'Facebook', 'https://www.facebook.com/sharer/sharer.php?u=' + encode(url)],
    ['x', 'X', 'https://twitter.com/intent/tweet?url=' + encode(url) + '&text=' + encode(text)],
    ['linkedin', 'LinkedIn', 'https://www.linkedin.com/sharing/share-offsite/?url=' + encode(url)],
    ['email', emailLabel, 'mailto:?subject=' + encode(title) + '&body=' + encode((text + '\n\n' + url).replace(/\n/g, '\r\n'))]
  ];

  const widget = document.createElement('div');
  widget.className = 'arma-share' + (guide ? ' arma-share-guide' : '');

  const button = document.createElement('button');
  button.className = 'arma-share-trigger';
  button.type = 'button';
  button.setAttribute('aria-expanded', 'false');
  button.setAttribute('aria-controls', 'arma-share-options');
  button.innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><path d="m8.7 10.6 6.6-4.2M8.7 13.4l6.6 4.2"/></svg>';
  const caption = document.createElement('span');
  caption.textContent = label;
  button.append(caption);

  const panel = document.createElement('div');
  panel.className = 'arma-share-menu';
  panel.id = 'arma-share-options';
  panel.hidden = true;
  panel.setAttribute('role', 'group');
  panel.setAttribute('aria-label', label);

  function track(method, stage) {
    document.dispatchEvent(new CustomEvent('arma:share', {detail: {method, stage}}));
  }

  function close(restoreFocus) {
    panel.hidden = true;
    button.setAttribute('aria-expanded', 'false');
    manualLink.hidden = true;
    if (restoreFocus) button.focus();
  }

  function open() {
    panel.hidden = false;
    button.setAttribute('aria-expanded', 'true');
    panel.querySelector('a').focus();
  }

  for (const [method, name, href] of destinations) {
    const link = document.createElement('a');
    link.href = href;
    link.textContent = name;
    if (method !== 'email') {
      link.target = '_blank';
      link.rel = 'noopener noreferrer';
    }
    link.addEventListener('click', () => {
      track(method, 'method');
      close(true);
    });
    panel.append(link);
  }

  const copy = document.createElement('button');
  copy.type = 'button';
  copy.className = 'arma-share-copy';
  copy.textContent = copyLabel;
  const manualLink = document.createElement('input');
  manualLink.className = 'arma-share-url';
  manualLink.type = 'url';
  manualLink.dir = 'ltr';
  manualLink.readOnly = true;
  manualLink.hidden = true;
  manualLink.value = url;
  manualLink.setAttribute('aria-label', copyLabel);
  manualLink.addEventListener('focus', () => manualLink.select());

  const status = document.createElement('span');
  status.className = 'arma-share-feedback';
  status.setAttribute('role', 'status');
  let feedbackTimer;
  let copying = false;
  copy.addEventListener('click', async () => {
    if (copying) return;
    copying = true;
    track('copy_link', 'method');
    let copied = false;
    try {
      await navigator.clipboard.writeText(url);
      copied = true;
    } catch (_) {
      if (!panel.hidden) {
        manualLink.hidden = false;
        manualLink.focus();
        try {
          copied = document.execCommand('copy');
        } catch (_) {}
        if (copied) {
          manualLink.hidden = true;
          copy.focus();
        }
      }
    } finally {
      copying = false;
    }
    if (copied) {
      status.textContent = copiedLabel;
      clearTimeout(feedbackTimer);
      feedbackTimer = setTimeout(() => { status.textContent = ''; }, 2500);
    }
  });

  let sharing = false;
  button.addEventListener('click', async () => {
    if (sharing) return;
    if (!panel.hidden) {
      close(true);
      return;
    }
    if (typeof navigator.share === 'function' &&
        (typeof navigator.canShare !== 'function' || navigator.canShare(shareData))) {
      sharing = true;
      try {
        const result = navigator.share(shareData);
        track('native', 'open');
        await result;
        return;
      } catch (error) {
        if (error?.name === 'AbortError') return;
      } finally {
        sharing = false;
      }
      track('fallback', 'fallback');
    } else {
      track('fallback', 'open');
    }
    open();
  });

  document.addEventListener('pointerdown', event => {
    if (!panel.hidden && !widget.contains(event.target)) close(panel.contains(document.activeElement));
  });
  widget.addEventListener('keydown', event => {
    if (event.key === 'Escape' && !panel.hidden) {
      event.preventDefault();
      close(true);
    }
  });
  widget.addEventListener('focusout', event => {
    if (!panel.hidden && event.relatedTarget && !widget.contains(event.relatedTarget)) close(false);
  });

  panel.append(copy, manualLink);
  widget.append(button, panel, status);
  if (art) {
    const column = document.createElement('div');
    column.className = 'arma-share-orbit';
    art.replaceWith(column);
    column.append(art, widget);
  } else {
    guide.append(widget);
  }
})();
