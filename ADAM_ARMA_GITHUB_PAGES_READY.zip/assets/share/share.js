/* ADAM ARMA sharing: lightweight, consent-free user action; never loads social scripts. */
(() => {
  'use strict';
  if (document.documentElement.dataset.armaShareReady) return;
  document.documentElement.dataset.armaShareReady = '1';
  const i18n = {
    ru:['Поделиться','Скопировать ссылку','Ссылка скопирована','Другие приложения'],
    en:['Share','Copy link','Link copied','Other apps'],
    ar:['مشاركة','نسخ الرابط','تم نسخ الرابط','تطبيقات أخرى'],
    zh:['分享','复制链接','链接已复制','其他应用'],
    es:['Compartir','Copiar enlace','Enlace copiado','Otras aplicaciones'],
    fr:['Partager','Copier le lien','Lien copié','Autres applications'],
    de:['Teilen','Link kopieren','Link kopiert','Weitere Apps'],
    it:['Condividi','Copia link','Link copiato','Altre app'],
    pt:['Compartilhar','Copiar link','Link copiado','Outros aplicativos'],
    tr:['Paylaş','Bağlantıyı kopyala','Bağlantı kopyalandı','Diğer uygulamalar'],
    pl:['Udostępnij','Kopiuj link','Link skopiowany','Inne aplikacje'],
    nl:['Delen','Link kopiëren','Link gekopieerd','Andere apps'],
    sv:['Dela','Kopiera länk','Länk kopierad','Andra appar'],
    cs:['Sdílet','Kopírovat odkaz','Odkaz zkopírován','Další aplikace'],
    el:['Κοινοποίηση','Αντιγραφή συνδέσμου','Ο σύνδεσμος αντιγράφηκε','Άλλες εφαρμογές'],
    uk:['Поділитися','Копіювати посилання','Посилання скопійовано','Інші застосунки'],
    kk:['Бөлісу','Сілтемені көшіру','Сілтеме көшірілді','Басқа қолданбалар'],
    uz:['Ulashish','Havolani nusxalash','Havola nusxalandi','Boshqa ilovalar'],
    he:['שיתוף','העתקת קישור','הקישור הועתק','יישומים נוספים'],
    fa:['اشتراک‌گذاری','کپی پیوند','پیوند کپی شد','برنامه‌های دیگر'],
    hi:['साझा करें','लिंक कॉपी करें','लिंक कॉपी हो गया','अन्य ऐप'],
    id:['Bagikan','Salin tautan','Tautan disalin','Aplikasi lain'],
    vi:['Chia sẻ','Sao chép liên kết','Đã sao chép liên kết','Ứng dụng khác'],
    th:['แชร์','คัดลอกลิงก์','คัดลอกลิงก์แล้ว','แอปอื่น'],
    ja:['共有','リンクをコピー','コピーしました','その他のアプリ'],
    ko:['공유','링크 복사','링크 복사됨','다른 앱'],
    bn:['শেয়ার করুন','লিঙ্ক কপি করুন','লিঙ্ক কপি হয়েছে','অন্যান্য অ্যাপ'],
    sw:['Shiriki','Nakili kiungo','Kiungo kimenakiliwa','Programu nyingine']
  };
  const lang = (document.documentElement.lang || 'en').toLowerCase().split('-')[0];
  const t = i18n[lang] || i18n.en;
  const rtl = document.documentElement.dir === 'rtl';
  const canonical = document.querySelector('link[rel="canonical"]')?.href;
  const url = canonical && /^https:\/\/adamarma\.ru\//i.test(canonical) ? canonical : location.origin + location.pathname;
  const title = document.querySelector('meta[property="og:title"]')?.content || document.title || 'ADAM ARMA';
  const svg = '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><path d="m8.7 10.6 6.6-4.2M8.7 13.4l6.6 4.2"/></svg>';
  let opened = null;
  const encode = encodeURIComponent;
  const dest = [
    ['Telegram', 'https://t.me/share/url?url=' + encode(url) + '&text=' + encode(title)],
    ['WhatsApp', 'https://api.whatsapp.com/send?text=' + encode(title + '\n' + url)],
    ['Facebook', 'https://www.facebook.com/sharer/sharer.php?u=' + encode(url)],
    ['VK', 'https://vk.com/share.php?url=' + encode(url) + '&title=' + encode(title)],
    ['X', 'https://twitter.com/intent/tweet?url=' + encode(url) + '&text=' + encode(title)],
    ['LinkedIn', 'https://www.linkedin.com/sharing/share-offsite/?url=' + encode(url)],
    ['Email', 'mailto:?subject=' + encode(title) + '&body=' + encode(url)]
  ];
  function close() {
    if (!opened) return;
    opened.menu.hidden = true;
    opened.button.setAttribute('aria-expanded', 'false');
    opened = null;
  }
  async function copy() {
    if (navigator.clipboard?.writeText) {
      try { await navigator.clipboard.writeText(url); return true; } catch (_) {}
    }
    const area = document.createElement('textarea');
    area.value = url; area.style.cssText = 'position:fixed;left:-9999px';
    document.body.appendChild(area); area.select();
    let ok = false;
    try { ok = document.execCommand('copy'); } catch (_) {}
    area.remove(); return ok;
  }
  function create(footer = false) {
    const wrap = document.createElement('span');
    wrap.className = 'arma-share' + (footer ? ' arma-share-footer-wrap' : '');
    wrap.dir = rtl ? 'rtl' : 'ltr';
    const button = document.createElement('button');
    button.type = 'button';
    button.className = footer ? 'arma-share-footer' : 'arma-share-trigger';
    button.setAttribute('aria-label', t[0]);
    button.setAttribute('aria-expanded', 'false');
    button.setAttribute('aria-haspopup', 'true');
    button.innerHTML = footer ? '' : svg + '<span class="arma-share-label"></span>';
    if (footer) button.textContent = t[0];
    else button.querySelector('.arma-share-label').textContent = t[0];
    const menu = document.createElement('div');
    menu.className = 'arma-share-menu';
    menu.hidden = true;
    menu.setAttribute('role', 'group');
    menu.setAttribute('aria-label', t[0]);
    menu.dir = rtl ? 'rtl' : 'ltr';
    dest.forEach(([name, href]) => {
      const link = document.createElement('a');
      link.href = href;
      link.textContent = name;
      if (!href.startsWith('mailto:')) {
        link.target = '_blank'; link.rel = 'noopener noreferrer';
      }
      link.addEventListener('click', close);
      menu.append(link);
    });
    const line = document.createElement('div'); line.className = 'arma-share-separator'; menu.append(line);
    const copied = document.createElement('button');
    copied.type = 'button'; copied.textContent = t[1];
    copied.addEventListener('click', async () => {
      if (await copy()) { copied.textContent = t[2]; setTimeout(() => { copied.textContent = t[1]; }, 1700); }
    });
    menu.append(copied);
    if (typeof navigator.share === 'function') {
      const system = document.createElement('button');
      system.type = 'button'; system.textContent = t[3];
      system.addEventListener('click', () => {
        close(); navigator.share({title, url}).catch(() => {});
      });
      menu.append(system);
    }
    button.addEventListener('click', () => {
      if (opened?.button === button) { close(); return; }
      close(); menu.hidden = false; button.setAttribute('aria-expanded', 'true');
      opened = {button, menu};
    });
    wrap.append(button, menu); return wrap;
  }
  function attach() {
    const header = document.querySelector('header.nav, header.read-nav');
    if (header && !header.querySelector('.arma-share')) {
      const widget = create(false);
      if (header.classList.contains('nav')) {
        const language = header.querySelector('.language-switch');
        if (language) {
          const tools = document.createElement('span');
          tools.className = 'arma-nav-extras';
          language.replaceWith(tools);
          tools.append(language, widget);
        } else header.append(widget);
      } else header.append(widget);
    }
    const footer = document.querySelector('footer.reading-footer, footer.guide-footer');
    if (footer && !footer.querySelector('.arma-share')) footer.append(create(true));
  }
  document.addEventListener('pointerdown', (ev) => {
    if (opened && !opened.menu.contains(ev.target) && !opened.button.contains(ev.target)) close();
  });
  document.addEventListener('keydown', (ev) => {
    if (ev.key === 'Escape' && opened) { const button = opened.button; close(); button.focus(); }
  });
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', attach, {once:true});
  else attach();
})();
